create procedure recompress_chunk(IN chunk regclass, IN if_not_compressed boolean DEFAULT true)
    SET search_path = pg_catalog, pg_temp
    language plpgsql
as
$$
BEGIN
  IF current_setting('timescaledb.enable_deprecation_warnings', true)::bool THEN
    RAISE WARNING 'procedure public.recompress_chunk(regclass,boolean) is deprecated and the functionality is now included in public.compress_chunk. this compatibility function will be removed in a future version.';
  END IF;
  PERFORM public.compress_chunk(chunk, if_not_compressed);
END$$;

alter procedure recompress_chunk(regclass, boolean, record) owner to health_user;

