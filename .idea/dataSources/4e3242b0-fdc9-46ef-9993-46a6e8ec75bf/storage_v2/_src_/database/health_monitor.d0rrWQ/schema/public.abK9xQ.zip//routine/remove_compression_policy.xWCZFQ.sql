create function remove_compression_policy(hypertable regclass, if_exists boolean default false) returns boolean
    strict
    SET search_path = pg_catalog, pg_temp
    language c
as
$fun$
DECLARE
    db text;
BEGIN
    SELECT current_database() INTO db;
    EXECUTE format($$ALTER DATABASE %I SET timescaledb.restoring ='on'$$, db);
    SET SESSION timescaledb.restoring = 'on';
    PERFORM _timescaledb_functions.stop_background_workers();
    RETURN true;
END
$fun$;

alter function remove_compression_policy(regclass, boolean) owner to health_user;

