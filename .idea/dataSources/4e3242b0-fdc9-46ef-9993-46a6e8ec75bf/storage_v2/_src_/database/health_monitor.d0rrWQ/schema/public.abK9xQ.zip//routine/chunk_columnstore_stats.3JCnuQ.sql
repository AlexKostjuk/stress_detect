create function chunk_columnstore_stats(hypertable regclass)
    returns TABLE(chunk_schema name, chunk_name name, compression_status text, before_compression_table_bytes bigint, before_compression_index_bytes bigint, before_compression_toast_bytes bigint, before_compression_total_bytes bigint, after_compression_table_bytes bigint, after_compression_index_bytes bigint, after_compression_toast_bytes bigint, after_compression_total_bytes bigint, node_name name)
    stable
    strict
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$SELECT * FROM public.chunk_compression_stats($1)$$;

alter function chunk_columnstore_stats(regclass) owner to health_user;

