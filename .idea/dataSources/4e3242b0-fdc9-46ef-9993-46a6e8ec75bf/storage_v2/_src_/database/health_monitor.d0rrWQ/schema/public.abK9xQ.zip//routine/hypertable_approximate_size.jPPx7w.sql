create function hypertable_approximate_size(hypertable regclass) returns bigint
    strict
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$
   SELECT sum(total_bytes)::bigint
   FROM public.hypertable_approximate_detailed_size(hypertable);
$$;

alter function hypertable_approximate_size(regclass) owner to health_user;

