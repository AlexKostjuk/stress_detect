create function timescaledb_pre_restore(chunk1 regclass, chunk2 regclass) returns boolean
    SET search_path = pg_catalog, pg_temp
    language plpgsql
as
$fun$
DECLARE
    db text;
BEGIN
    SELECT current_database() INTO db;
    EXECUTE format($$ALTER DATABASE %I SET timescaledb.restoring ='on'$$, db);
    SET SESSION timescaledb.restoring = 'on';
    PERFORM _timescaledb_functions.stop_background_workers();
    RETURN true;
END
$fun$;

alter function timescaledb_pre_restore(regclass, regclass) owner to health_user;

