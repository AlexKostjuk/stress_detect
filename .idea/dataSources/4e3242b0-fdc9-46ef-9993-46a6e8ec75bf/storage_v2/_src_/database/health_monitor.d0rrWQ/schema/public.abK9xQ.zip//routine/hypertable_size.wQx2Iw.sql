create function hypertable_size(hypertable regclass) returns bigint
    strict
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$
   SELECT total_bytes::bigint FROM public.hypertable_detailed_size(hypertable);
$$;

alter function hypertable_size(regclass) owner to health_user;

