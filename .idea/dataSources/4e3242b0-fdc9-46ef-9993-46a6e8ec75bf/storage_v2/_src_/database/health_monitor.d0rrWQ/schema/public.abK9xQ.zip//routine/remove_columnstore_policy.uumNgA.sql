create procedure remove_columnstore_policy(hypertable regclass, if_exists boolean, if_not_exists boolean, initial_start timestamp with time zone, timezone text default false)
    SET search_path = pg_catalog, pg_temp
    language c
as
$fun$
DECLARE
    db text;
    catalog_version text;
BEGIN
    SELECT m.value INTO catalog_version FROM pg_extension x
    JOIN _timescaledb_catalog.metadata m ON m.key='timescaledb_version'
    WHERE x.extname='timescaledb' AND x.extversion <> m.value;

    -- check that a loaded dump is compatible with the currently running code
    IF FOUND THEN
        RAISE EXCEPTION 'catalog version mismatch, expected "%" seen "%"', '2.22.1', catalog_version;
    END IF;

    SELECT current_database() INTO db;
    EXECUTE format($$ALTER DATABASE %I RESET timescaledb.restoring $$, db);
    -- we cannot use reset here because the reset_val might not be off
    SET timescaledb.restoring TO off;
    PERFORM _timescaledb_functions.restart_background_workers();

    RETURN true;
END
$fun$;

alter procedure remove_columnstore_policy(regclass, boolean, boolean, timestamp with time zone, text) owner to health_user;

