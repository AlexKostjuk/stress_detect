create function cleanup_free_users_data(job_id integer, config jsonb) returns void
    language plpgsql
as
$$
        BEGIN
            DELETE FROM a_sensor_vectors v
            USING users u
            JOIN user_retention ur ON ur.user_id = u.id
            WHERE v.user_id = u.id
              AND u.user_type = 'free'
              AND v.timestamp < now() - (ur.retention_days || ' days')::interval;
        END;
        $$;

alter function cleanup_free_users_data(integer, jsonb) owner to health_user;

