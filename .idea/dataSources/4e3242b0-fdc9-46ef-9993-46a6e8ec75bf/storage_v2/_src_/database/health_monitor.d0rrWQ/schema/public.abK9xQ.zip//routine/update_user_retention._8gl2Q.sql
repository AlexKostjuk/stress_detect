create function update_user_retention() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF NEW.user_type = 'premium' THEN
                INSERT INTO user_retention (user_id, retention_days, updated_at)
                VALUES (NEW.id, 365, now())
                ON CONFLICT (user_id) DO UPDATE
                SET retention_days = 365, updated_at = now();
            ELSE
                INSERT INTO user_retention (user_id, retention_days, updated_at)
                VALUES (NEW.id, 60, now())
                ON CONFLICT (user_id) DO UPDATE
                SET retention_days = 60, updated_at = now();
            END IF;
            RETURN NEW;
        END;
        $$;

alter function update_user_retention() owner to health_user;

