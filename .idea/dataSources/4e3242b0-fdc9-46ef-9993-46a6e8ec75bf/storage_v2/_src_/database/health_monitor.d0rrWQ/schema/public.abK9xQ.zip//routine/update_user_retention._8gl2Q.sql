create function update_user_retention() returns trigger
    language plpgsql
as
$$
        BEGIN
            INSERT INTO user_retention (user_id, retention_days, updated_at)
            VALUES (NEW.id, CASE WHEN NEW.user_type = 'premium' THEN 365 ELSE 60 END, now())
            ON CONFLICT (user_id) DO UPDATE
            SET retention_days = EXCLUDED.retention_days, updated_at = now();
            RETURN NEW;
        END;
        $$;

alter function update_user_retention() owner to health_user;

