create function hypertable_columnstore_stats(hypertable regclass)
    returns TABLE(total_chunks bigint, number_compressed_chunks bigint, before_compression_table_bytes bigint, before_compression_index_bytes bigint, before_compression_toast_bytes bigint, before_compression_total_bytes bigint, after_compression_table_bytes bigint, after_compression_index_bytes bigint, after_compression_toast_bytes bigint, after_compression_total_bytes bigint, node_name name)
    stable
    strict
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$SELECT * FROM public.hypertable_compression_stats($1)$$;

alter function hypertable_columnstore_stats(regclass) owner to health_user;

