create function alter_job(IN chunk regclass, IN if_not_compressed boolean DEFAULT true)
    returns table("job_id" integer, "schedule_interval" interval, "max_runtime" interval, "max_retries" integer, "retry_period" interval, "scheduled" boolean, "config" jsonb, "next_start" timestamp with time zone, "check_config" text, "fixed_schedule" boolean, "initial_start" timestamp with time zone, "timezone" text, "application_name" name)
    SET search_path = pg_catalog, pg_temp
    language c
as
$$
BEGIN
  IF current_setting('timescaledb.enable_deprecation_warnings', true)::bool THEN
    RAISE WARNING 'procedure public.recompress_chunk(regclass,boolean) is deprecated and the functionality is now included in public.compress_chunk. this compatibility function will be removed in a future version.';
  END IF;
  PERFORM public.compress_chunk(chunk, if_not_compressed);
END$$;

alter function alter_job(integer, interval, interval, integer, interval, boolean, jsonb, timestamp with time zone, boolean, regproc, boolean, timestamp with time zone, text, text) owner to health_user;

